<template>
  <div class="main">
    <div>角色管理</div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
  .main {
    display: flex;
    justify-content: center;
    align-items: center;
    background: whitesmoke;
    width: 100%;
    height: 500px;
  }
</style>
