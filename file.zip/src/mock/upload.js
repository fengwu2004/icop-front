export default {
  picFile: config => {
  
    console.log(config)
    
    return {
    
    }
  },
}
