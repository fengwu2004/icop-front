export const pushStatusKeyList = [{ text: '待推送', value: 'UNPUSH' }, { text: '不推送', value: 'NOPUSH' }, { text: '推送成功', value: 'SUCCESS' }, { text: '推送失败', value: 'FAIL' }]
export const noticeTypeKeyList = [{ text: '安全防范公告', value: 'SAFE_GUARD_INFORM' }, { text: '物业风采', value: 'OFFICE_STYLE' }, { text: '电梯维修保养', value: 'ELEVATOR_MAINTENANCE' }, { text: '投票及调查互动', value: 'INVESTIGATE_INTERACT' }, { text: '商店优惠公告', value: 'STORE_PREFERENTIAL' }]
export const pushChannelKeyList = [{ text: 'APP推送', value: 'APP' }, { text: '短信', value: 'SMS' }]
export const strategyKeyList = [{ text: '立即生效', value: 'IMMEDIATE' }, { text: '定时生效', value: 'TIMES' }]
