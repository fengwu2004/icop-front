export let headercellcenter = {textAlign:'center', backgroundColor:'#F4F6F9', color:'#445577'}

export let headercell = {textAlign:'left', backgroundColor:'#F4F6F9',color:'#445577'}

export let normalcellcenter = {textAlign:'center', color:'#16325C'}

export let normalcell = {textAlign:'left', color:'#16325C'}
